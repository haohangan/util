package grg.aptoto.im.user;

public interface AbstractUser {
//	public static final String jsonkey  = "imKey";// 用户id
	
	public static final String key = "user";// 用户id
	
	public static final String INFO = "name";// 用户id

//	public static final String CHAT_ID = "chatId";//会话id
}
