package grg.aptoto.im.cometd;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import grg.aptoto.im.ScheduleService;

@WebServlet(name = "loop", urlPatterns = "/loop")
public class LoopServlet extends HttpServlet {
	private static final long serialVersionUID = -156692852673139318L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("Content-type", "text/html;charset=UTF-8");
		ServletOutputStream out = resp.getOutputStream();
		resp.setContentType("multipart/x-mixed-replace;boundary=End");
		out.println();
		out.println("--End");
		int i = 0;
		while (i < 1000) {
			out.println("Content-Type:text/plain;charset=UTF-8");
			out.println();
			i++;
			String str = "";
			str = i + "   =\r\n" + ScheduleService.s;
			// System.out.println(str);
			out.println(str);
			out.println();
			out.println("--End");
			out.flush();
			try {
				Thread.sleep(1000 * 10);
			} catch (InterruptedException e) {
			}
		}
		out.close();
	}

}