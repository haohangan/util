/**   
 * 文件名：ChatService.java </br>
 * 描述：</br>
 */

package grg.aptoto.im;

import java.util.Map;

import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.ConfigurableServerChannel;
import org.cometd.bayeux.server.LocalSession;
import org.cometd.bayeux.server.ServerMessage;
import org.cometd.bayeux.server.ServerSession;
import org.cometd.oort.Oort;
import org.cometd.oort.Seti;
import org.cometd.server.AbstractService;

import grg.aptoto.im.user.Users;

/**
 * 类名: ChatService </br>
 * 包名：grg.aptoto.im </br>
 * 描述: </br>
 * 发布版本号：</br>
 * 开发人员： 何锦荣 </br>
 * 创建时间： 2016-6-8 </br>
 */

public class ChatService extends AbstractService {

	// public static final Users ALL = Users.INSTANCE;//
	// 存放所有用户session的map（不区分用户种类）

	public static final String CHART_SERVICE = "/chat/chat";// 普通消息的通道

	// public static final String NOTICE_SERVICE = "/chat/*";// 反馈消息的通道
	//
	// public static final String ALL_SERVICE = "/service/**";// 反馈消息的通道
	public static final String BROAD_CAST = "/chat/broad";
	
	public static final String BROAD_CAST_CHANNEL = "/chat/channel";
	
	private final Oort _oort;
	private final Seti _seti;

	public static final String TID = "tid";

	/**
	 * 描述: </br>
	 * 开发人员：何锦荣 </br>
	 * 创建时间：2016-6-8 </br>
	 * 
	 * @param bayeux
	 * @param name
	 *            </br>
	 */
	public ChatService(BayeuxServer bayeux, Oort oort, Seti seti) {
		super(bayeux, "chat");
		_oort = oort;
		_seti = seti;
		addService(CHART_SERVICE, "processChat");
		bayeux.createChannelIfAbsent(BROAD_CAST, new ConfigurableServerChannel.Initializer.Persistent());
		// addService(NOTICE_SERVICE, "notice");
		// addService(ALL_SERVICE, "all");

		_oort.observeChannel(BROAD_CAST);
		addService(BROAD_CAST, "all");
		// _seti.addPresenceListener(new Seti.PresenceListener(){
		//
		// @Override
		// public void presenceAdded(Event event) {
		// System.out.printf("presenceAdded User ID %s is now present in node
		// %s%n", event.getUserId(), event.getOortURL());
		// Oort oort = _seti.getOort();
		// String oortURL = event.getOortURL();
		// OortComet oortComet = oort.getComet(oortURL);
		//
		// Map<String, Object> data = new HashMap<String, Object>();
		// data.put("content", "来自节点1");
		// data.put("user", event.getUserId());
		//
		// oortComet.getChannel(CHART_SERVICE).publish(data);
		// }
		//
		// @Override
		// public void presenceRemoved(Event event) {
		// System.out.printf("presenceRemoved User ID %s is now absent in node
		// %s%n", event.getUserId(), event.getOortURL());
		// }
		//
		// });
		// _seti.associate("", "");
		// _oort.observeChannel("");
	}

	/**
	 * 
	 * 方法名: </br>
	 * 详述: </br>
	 * 开发人员：何锦荣 </br>
	 * 创建时间：2016-6-8 </br>
	 * 
	 * @param remote
	 * @param message
	 *            </br>
	 *            接收并转发消息：普通消息
	 */
	public void processChat(ServerSession remote, ServerMessage message) {
		Map<String, Object> input = message.getDataAsMap();
		String tid = (String) input.get(TID);
		System.out.println("CHART_SERVICE\t发送给：" + tid + "\t" + input.get("content"));
		// 将信息发送给订阅了“/service/notice”通道的用户:name，peer-to-peer
		if (Users.INSTANCE.contains(tid)) {
			System.out.println("就在此节点");
			send(Users.INSTANCE.get(tid), CHART_SERVICE, input);
		} else {
			_logger.info("processChat:用户{}不在此節點1", tid);
			System.out.println(_oort.getURL());
			System.out.println("==============");
			for (String s : _oort.getKnownComets()) {
				System.out.println(s);
			}
			System.out.println("--------------");
			_seti.sendMessage(tid, CHART_SERVICE, input);
			// _oort.getBayeuxServer().getChannel(CHART_SERVICE).publish(remote,
			// input);
		}
		// System.out.println("processChat:" + input);
	}

	/**
	 * 反馈消息
	 * 
	 * @param remote
	 * @param message
	 */
	// public void notice(ServerSession remote, ServerMessage message) {
	// Map<String, Object> input = message.getDataAsMap();
	// // String tid = (String) input.get(TID);
	// // if (Users.INSTANCE.contains(tid)) {
	// // send(Users.INSTANCE.get(tid), NOTICE_SERVICE, input);
	// // System.out.print("NOTICE_SERVICE\t");
	// // } else {
	// // _logger.info("notice:用户{}没有打开此会话", tid);
	// // }
	// System.out.println("notice:" + input);
	// }

	public void all(ServerSession remote, ServerMessage message) {
		Map<String, Object> input = message.getDataAsMap();
		System.out.println("all:节点1" + input);
		_oort.getBayeuxServer().getChannel(BROAD_CAST_CHANNEL).publish(getLocalSession(), input);
	}

	// public void setCLUSTER(Oort oort, Seti seti) {
	// this._oort = oort;
	// this._seti = seti;
	// }
}
