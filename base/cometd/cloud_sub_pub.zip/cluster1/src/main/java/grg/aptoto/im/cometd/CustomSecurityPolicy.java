/**   
 * 文件名：CustomSecurityPolicy.java </br>
 * 描述：</br>
 */

package grg.aptoto.im.cometd;

import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.ServerMessage;
import org.cometd.bayeux.server.ServerSession;
import org.cometd.oort.Oort;
import org.cometd.oort.Seti;
import org.cometd.server.DefaultSecurityPolicy;

import grg.aptoto.im.Utils;
import grg.aptoto.im.user.AbstractUser;
import grg.aptoto.im.user.Users;

/**
 * 类名: CustomSecurityPolicy </br>
 * 包名：grg.aptoto.im.cometd </br>
 * 描述: 自定义comted握手安全策略</br>
 * 发布版本号：</br>
 * 开发人员： 何锦荣 </br>
 * 创建时间： 2016-6-8 </br>
 */

public class CustomSecurityPolicy extends DefaultSecurityPolicy {
	private static String nodeName = "一号节点";

	// @SuppressWarnings("unused")
	private final Oort _oort;
	private final Seti _seti;

	public CustomSecurityPolicy(Oort oort, Seti seti) {
		super();
		this._oort = oort;
		this._seti = seti;
		System.out.println("初始化 CustomSecurityPolicy start");
		System.out.println(_seti.getId() + "\t" + _seti.getState() + "\t" + _seti.getOort());
		for (String u : _seti.getUserIds()) {
			System.out.println(u);
		}
		System.out.println("初始化 CustomSecurityPolicy  結束");
	}

	@Override
	public boolean canHandshake(BayeuxServer server, ServerSession session, final ServerMessage message) {
		System.out.println("尝试进入:" + nodeName);
		// 验证用户
		// Services can always handshake
		if (session.isLocalSession()) {
			System.out.println("isLocalSession 成功进入:" + nodeName);
			return true;
		}

		// Other oort nodes can always handshake (they must be configured with
		// the same oort secret)
		if (_oort.isOortHandshake(message)) {
			System.out.println("cloud 成功进入:" + nodeName);
			Utils.print(message.getDataAsMap());
			System.out.println("结束cloud------------");
			return true;
		}

		// Remote users must authenticate
		return authenticate(session, message);
	}

	private boolean authenticate(ServerSession session, ServerMessage message) {
		System.out.println("尝试 authenticate:" + nodeName);
		Object userObj = message.get(AbstractUser.key);
		Object userName = message.get(AbstractUser.INFO);
		if (userObj == null) {
			System.out.println(" authenticate 失败进入:" + nodeName);
			return Boolean.FALSE;
		}
		if (userName != null) {
			session.setAttribute(AbstractUser.INFO, userName.toString());
		}
		final String user = userObj.toString();
		Users.INSTANCE.add(user, session);// 登陆
		_seti.associate(user, session);//
		// if (_oort.isOort(session)) {
		// System.out.println("_seti.associate(user, session):" + nodeName);
		// _seti.associate(user, session);// associate
		// }

		session.addListener(new ServerSession.RemoveListener() {

			@Override
			public void removed(ServerSession session, boolean timeout) {
				System.out.println("超时下线:" + nodeName);
				Users.INSTANCE.remove(user);
				_seti.disassociate(user, session);
				// if (_oort.isOort(session)) {
				// System.out.println("_seti.disassociate(user, session):" +
				// nodeName);
				// _seti.disassociate(user, session);
				// }
			}// 下线操作

		});
		System.out.println("authenticate 成功进入:" + nodeName);
		return Boolean.TRUE;
	}

}
