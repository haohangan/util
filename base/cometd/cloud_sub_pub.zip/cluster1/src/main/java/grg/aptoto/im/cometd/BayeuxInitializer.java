/**   
 * 文件名：BayeuxInitializer.java </br>
 * 描述：</br>
 */ 

package grg.aptoto.im.cometd;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;

/** 
 * 类名: BayeuxInitializer </br>
 * 包名：grg.aptoto.im.cometd </br>
 * 描述: 集中配置cometd的Listener</br>
 * 发布版本号：</br>
 * 开发人员： 何锦荣 </br>
 * 创建时间： 2016-6-8 </br>
 */

public class BayeuxInitializer implements ServletContextAttributeListener {

	/* 
	 * @see javax.servlet.ServletContextAttributeListener#attributeAdded(javax.servlet.ServletContextAttributeEvent)
	 * 开发人员：何锦荣
	 */
	@Override
	public void attributeAdded(ServletContextAttributeEvent event) {
	}

	/* 
	 * @see javax.servlet.ServletContextAttributeListener#attributeRemoved(javax.servlet.ServletContextAttributeEvent)
	 * 开发人员：何锦荣
	 */
	@Override
	public void attributeRemoved(ServletContextAttributeEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	/* 
	 * @see javax.servlet.ServletContextAttributeListener#attributeReplaced(javax.servlet.ServletContextAttributeEvent)
	 * 开发人员：何锦荣
	 */
	@Override
	public void attributeReplaced(ServletContextAttributeEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
