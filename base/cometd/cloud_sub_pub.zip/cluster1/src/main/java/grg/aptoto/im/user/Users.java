package grg.aptoto.im.user;

import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.cometd.bayeux.server.ServerSession;

public enum Users {

	INSTANCE;

	private ConcurrentMap<String, ServerSession> users = new ConcurrentHashMap<>();

	public void add(String userid, ServerSession session) {
		if (users.containsKey(userid)) {
			System.out.println("重复上线");
			users.get(userid).disconnect();
			users.remove(userid);
		}
		users.put(userid, session);
	}


	public ServerSession get(String userid) {
		return users.get(userid);
	}

	public boolean contains(String userid) {
		if (users.containsKey(userid)) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	public void remove(String userid) {
		System.out.println("下线操作："+userid);
		if (users.containsKey(userid)) {
			users.remove(userid);
		}
	}

	public int getNum() {
		return users.size();
	}
	
	
	public  Set<Entry<String, ServerSession>>  showUser(){
		return users.entrySet();
	}
}
