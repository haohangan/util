package grg.aptoto.im;

import java.util.Map;
import java.util.Set;

public class Utils {
   public static void print(Map<String,Object> map){
	   if(map==null){
		   System.out.println("map is null！");
		   return;
	   }
	   
	   Set<Map.Entry<String,Object>>  set = map.entrySet();
	   System.out.println("Utils start\t");
	   for(Map.Entry<String,Object> entry:set){
		   System.out.println(entry.getKey()+" : "+entry.getValue()+"\t");
	   }
	   System.out.println("Utils end");
	   System.out.println();
   }
   
   public static void print2(Map<String,String> map){
	   Set<Map.Entry<String,String>>  set = map.entrySet();
	   System.out.println("start\t");
	   for(Map.Entry<String,String> entry:set){
		   System.out.println(entry.getKey()+" : "+entry.getValue()+"\t");
	   }
	   System.out.println("end");
	   System.out.println();
   }
}
