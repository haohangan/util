package grg.aptoto.im.cometd;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.oort.Oort;
import org.cometd.oort.Seti;

import grg.aptoto.im.ChatService;
import grg.aptoto.im.ScheduleService;

public class InitServiceServlet extends HttpServlet {

	private static final long serialVersionUID = -7358432956730561627L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.sendError(503);
	}

	@Override
	public void init() throws ServletException {
		super.init();
		ServletContext context = getServletContext();
		Oort oort = (Oort) context.getAttribute(Oort.OORT_ATTRIBUTE);
		Seti seti = (Seti) context.getAttribute(Seti.SETI_ATTRIBUTE);
//		System.out.println("1:"+oort.getId());
//		System.out.println("2:"+seti.getOort().getId());
//		System.out.println(oort.equals(seti.getOort()));
//		System.out.println(oort==seti.getOort());
		BayeuxServer bayeux = (BayeuxServer) getServletContext().getAttribute(BayeuxServer.ATTRIBUTE);
		CustomSecurityPolicy customSecurityPolicy = new CustomSecurityPolicy(oort,seti);
		bayeux.setSecurityPolicy(customSecurityPolicy);
		new ChatService(bayeux, oort, seti);
		new ScheduleService(bayeux,oort,seti);
	}

}