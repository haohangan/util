package grg.aptoto.im;

import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.ServerChannel;
import org.cometd.bayeux.server.ServerSession;
import org.cometd.oort.Oort;
import org.cometd.oort.Seti;

import grg.aptoto.im.user.AbstractUser;
import grg.aptoto.im.user.Users;

public class ScheduleService {

	private final Oort _oort;
	private final Seti _seti;

	public static ScheduledExecutorService pool = Executors.newSingleThreadScheduledExecutor();
	public static String s = "";
	static String RN = "\r\n";
	static String EP = "\t\t";

	BayeuxServer bayeux;

	public ScheduleService(BayeuxServer bayeux, Oort oort, Seti seti) {
		this.bayeux = bayeux;
		_oort = oort;
		_seti = seti;
		pool.scheduleAtFixedRate(new Run(bayeux,_oort,_seti), 10, 10, TimeUnit.SECONDS);
	}

	static class Run implements Runnable {
		BayeuxServer bayeux;
		Oort _oort;
		Seti _seti;

		public Run(BayeuxServer bayeux, Oort oort, Seti seti) {
			this.bayeux = bayeux;
			_oort = oort;
			_seti = seti;
		}

		@Override
		public void run() {
			StringBuffer sb = new StringBuffer();

			for (ServerChannel sc : bayeux.getChannels()) {
				Set<ServerSession> subs = sc.getSubscribers();
				sb.append(sc.getId());
				sb.append(" 订阅数：");
				sb.append(subs.size());
				sb.append(RN);
			}
			sb.append("当前节点的Users中用戶数目：");
			sb.append(Users.INSTANCE.getNum());
			sb.append(RN);
			sb.append("所有用户详情");
			sb.append(RN);
			for (Entry<String, ServerSession> entry : Users.INSTANCE.showUser()) {
				sb.append(entry.getKey());
				sb.append("\t|\t");
				sb.append(entry.getValue().getAttribute(AbstractUser.INFO));
				sb.append(RN);
			}
			sb.append(RN);
			sb.append("查看奥特集群状态");
         sb.append(RN);
         sb.append("OORT_ID:");
         sb.append(_oort.getId());
         sb.append(EP);
         sb.append(_oort.getURL());
         sb.append(EP);
         sb.append(_oort.getState());
         sb.append(RN);
         sb.append("SETI_ID:");
         sb.append(_seti.getId());
         sb.append(RN);
         sb.append("_seti list");
         sb.append(EP);
         sb.append(_seti.getState());
         sb.append(RN);
         sb.append("本节点人数：");
         Set<String> us = _seti.getUserIds();
         sb.append(us.size());
         sb.append(RN);
         for(String s:us){
        	 sb.append(s);
        	 sb.append(RN);
         }
			s = sb.toString();
		}

	}
}
