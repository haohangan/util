
package grg.aptoto.im.cometd;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.cometd.bayeux.server.BayeuxServer;
import org.cometd.bayeux.server.ServerChannel;
import org.cometd.server.authorizer.GrantAuthorizer;
import org.cometd.server.ext.AcknowledgedMessagesExtension;
import org.cometd.server.ext.TimesyncExtension;

/**
 * 
 * 类名: CometDInitializer </br>
 * 包名：grg.aptoto.im </br>
 * 描述: 集中配置cometd的service</br>
 * 发布版本号：</br>
 * 开发人员： 何锦荣 </br>
 * 创建时间： 2016-6-8 </br>
 */
public class CometDInitializer extends GenericServlet {

	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		BayeuxServer bayeux = (BayeuxServer) getServletContext().getAttribute(BayeuxServer.ATTRIBUTE);
		bayeux.addExtension(new TimesyncExtension());
		bayeux.addExtension(new AcknowledgedMessagesExtension());

		// allow anybody to handshake
		bayeux.getChannel(ServerChannel.META_HANDSHAKE).addAuthorizer(GrantAuthorizer.GRANT_PUBLISH);

		// ServletContext context = getServletContext();
		// Oort oort = (Oort) context.getAttribute(Oort.OORT_ATTRIBUTE);
		// Seti seti = (Seti) context.getAttribute(Seti.SETI_ATTRIBUTE);

		// 自定义安全访问策略
		// CustomSecurityPolicy customSecurityPolicy = new
		// CustomSecurityPolicy(seti);
		// bayeux.setSecurityPolicy(customSecurityPolicy);

		// new ChatService(bayeux,oort, seti);
		// new ScheduleService(bayeux);
	}

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// throw new ServletException();
		((HttpServletResponse) response).sendError(503);
	}
}
